package com.example.rules;

import org.springframework.stereotype.Component;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class RuleRegistry {
    private final Map<String, Boolean> ruleStates = new ConcurrentHashMap<>();

    public boolean isEnabled(String ruleId) {
        return ruleStates.getOrDefault(ruleId, true);
    }

    public void setEnabled(String ruleId, boolean enabled) {
        ruleStates.put(ruleId, enabled);
    }

    public Map<String, Boolean> getAll() {
        return Collections.unmodifiableMap(ruleStates);
    }
}