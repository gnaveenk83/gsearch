package com.example.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/rules")
public class RuleController {

    @Autowired
    private RuleRegistry ruleRegistry;

    @GetMapping
    public ResponseEntity<Map<String, Boolean>> listRules() {
        return ResponseEntity.ok(ruleRegistry.getAll());
    }

    @PostMapping("/{ruleId}")
    public ResponseEntity<String> toggleRule(@PathVariable String ruleId, @RequestParam boolean enabled) {
        ruleRegistry.setEnabled(ruleId, enabled);
        return ResponseEntity.ok("Rule " + ruleId + " set to " + enabled);
    }
}