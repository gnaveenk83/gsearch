package com.example.rules;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/execute")
public class RuleRunner {

    @Autowired
    private RuleRegistry ruleRegistry;

    private final KieSession kieSession;

    public RuleRunner() {
        KieServices kieServices = KieServices.Factory.get();
        KieContainer kieContainer = kieServices.getKieClasspathContainer();
        this.kieSession = kieContainer.newKieSession("ksession-rules");
    }

    @PostMapping
    public String executeRules(@RequestBody PurchaseOrder po) {
        po.setRuleRegistry(ruleRegistry);
        kieSession.insert(po);
        kieSession.fireAllRules();
        return "Rules executed";
    }
}