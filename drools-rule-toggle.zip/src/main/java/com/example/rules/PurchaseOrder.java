package com.example.rules;

import java.util.List;

public class PurchaseOrder {
    private transient RuleRegistry ruleRegistry;
    private List<LineItem> lineItems;

    public boolean isRuleEnabled(String ruleId) {
        return ruleRegistry != null && ruleRegistry.isEnabled(ruleId);
    }

    public void setRuleRegistry(RuleRegistry registry) {
        this.ruleRegistry = registry;
    }

    public List<LineItem> getLineItems() {
        return lineItems;
    }

    public void setLineItems(List<LineItem> lineItems) {
        this.lineItems = lineItems;
    }

    public void reject(String reason) {
        System.out.println("Rejected: " + reason);
    }
}