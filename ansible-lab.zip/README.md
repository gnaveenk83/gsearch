# Ansible Lab - 2 Node Docker Setup

## Setup Instructions

1. Start containers:
   ```bash
   docker-compose up -d
   ```

2. Run the playbook:
   ```bash
   ansible-playbook -i inventory.ini playbook.yml
   ```

This will:
- Ping both nodes
- Create a user
- Install `htop`
- Print a message


---

## Additional Examples

You can try running other playbooks from the `examples/` folder:

```bash
ansible-playbook -i inventory.ini examples/users.yml
ansible-playbook -i inventory.ini examples/file-ops.yml
ansible-playbook -i inventory.ini examples/service-check.yml
ansible-playbook -i inventory.ini examples/facts-demo.yml
```

These examples cover:
- Creating multiple users
- Managing files and directories
- Ensuring services are running
- Displaying system facts
